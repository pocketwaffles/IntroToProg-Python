# -------------------------------------------------#
# Title: Example of Error Handling
# Dev:   Adam Wirtala
# Date:  August 25, 2019
# ChangeLog: (Who, When, What)
#   Adam Wirtala, 08/25/2019, Created Example
#--------------------------------------------------#

#-------Setup-------#

# First, we need to import the module built within python in order to handle pickling data
# Pickling data refers to storing the data in its current state without the need to convert to a string
# and storing that data into a binary file (as opposed to a text file as python would natively prefer).
import pickle

#-------Data-------#
# Define Variables, we have set up the inventory items in their own class
lstInventory = []

class Inventory:
    intItemID = ""
    strItemName = ""
    fltItemCost = ""


# I want to read the contents of the file if any and present them to the user.  If i try to open a file with the "rb" tag,
# We can add a "try/except" block to help handle this error and continue with the program instead of crashing.
# The "exception" modifier is a catch-all for errors, in this case, since it's just the one error we are using that in lieu of finding something specific.
try:
    with open("inventory.dat", "rb") as file:
        lstInventory = pickle.load(file)
        print("Your Current Inventory is:")
        for items in lstInventory:
            print(items)
except Exception:
    print("You don't have any items in your Inventory currently, please add some!")

# Next we will create a binary data file where we will store the inventory
objFile = open("inventory.dat", "ab") #"ab" stands for "append binary", this is used to create a file if no file previously exists.
objFile.close()


#-------Processing-------#
# This time we wanted to incorporate the data processing into a function that would allow us to call it from the data input
def InventoryAdd():
    # I used a while loop for both the Item's ID and Cost as I wanted to force the user to enter values in the correct format before trying to add them to a list
    # and therefore causing further errors.  If the user enters data in the correct format, then the while loop will break and the program will continue.
    while (True):
        try:
            Inventory.strItemID = int(input("Please enter an Item ID: "))
            break
        except ValueError:
            print("Please enter a number instead!")
    Inventory.strItemName = str(input("Please enter an Item Description: "))
    while (True):
        try:
            Inventory.strItemCost = float(input("Please enter an Item Cost: "))
            break
        except ValueError:
            print("Please enter just a number value!")
    lstNewRow = [Inventory.strItemID, Inventory.strItemName, Inventory.strItemCost]
    lstInventory.append(lstNewRow)


#-------I/O-------#
# Then we will allow the user to add items to the inventory list that will later be saved to the file.

while (True):
    InventoryAdd()
    strAnotherItem = input("Would you like to enter another item? (y/n): ")
    if strAnotherItem.lower() == "n": break

# This is to allow the user to end the program without saving anything to file as I haven't incorporated a deletion method in this example.
strEndProgram = input("Would you like to save the data to file? (y/n): ")
if strEndProgram.lower() == "y":

# This set of code uses the pickle module, and opens the file up for us to be able to dump our data into the file using the pickle.dump() method.  We do need to tell
# python which data to load, and into which file we want it saved.
    objFile = open("inventory.dat", "wb")
    pickle.dump(lstInventory, objFile)
    objFile.close()
# To make sure that the data is saved correctly, we then re-open the file in read only mode using the "rb" tag, and load back the data from our binary file into an object
# in python that we can then use.  In this case I use lstInventory to s how that we are in fact loading data from the file and not using information stored in the program's memory.
    objFile = open("inventory.dat", "rb")
    lstInventory = pickle.load(objFile)
    print("Your inventory is as follows:")
    for items in lstInventory:
        print(items)
# This informs the user that the data wasn't saved and the program has run its course.
elif strEndProgram.lower() == "n":
    print("Nothing was saved, please restart the program to try again!")

