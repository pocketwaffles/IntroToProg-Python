# -------------------------------------------------#
# Title: Example of Pickling Data
# Dev:   Adam Wirtala
# Date:  August 25, 2019
# ChangeLog: (Who, When, What)
#   Adam Wirtala, 08/25/2019, Created Example
#--------------------------------------------------#

#-------Setup-------#

# First, we need to import the module built within python in order to handle pickling data
# Pickling data refers to storing the data in its current state without the need to convert to a string
# and storing that data into a binary file (as opposed to a text file as python would natively prefer).
import pickle

#-------Data-------#
# Define Variables, we have set up the inventory items in their own class
lstInventory = []

class Inventory:
    strItemID = ""
    strItemName = ""
    strItemCost = ""


# Next we will create a binary data file where we will store the inventory
objFile = open("inventory.dat", "ab") #"ab" stands for "append binary", this is used to create a file if no file previously exists.

objFile.close()


#-------I/O-------#
# Then we will allow the user to add items to the inventory list that will later be saved to the file.
while (True):
    Inventory.strItemID = input("Please enter an Item ID: ")
    Inventory.strItemName = input("Please enter an Item Description: ")
    Inventory.strItemCost = input("Please enter an Item Cost: ")
    lstNewRow = [Inventory.strItemID, Inventory.strItemName, Inventory.strItemCost]
    lstInventory.append(lstNewRow)
    strAnotherItem = input("Would you like to enter another item? (y/n): ")
    if strAnotherItem.lower() == "n": break

#-------Processing-------#
# This set of code uses the pickle module, and opens the file up for us to be able to dump our data into the file using the pickle.dump() method.  We do need to tell
# python which data to load, and into which file we want it saved.
objFile = open("inventory.dat", "wb")
pickle.dump(lstInventory, objFile)
objFile.close()

# To make sure that the data is saved correctly, we then re-open the file in read only mode using the "rb" tag, and load back the data from our binary file into an object
# in python that we can then use.  In this case I use lstInventory to show that we are in fact loading data from the file and not using information stored in the program's memory.
objFile = open("inventory.dat", "rb")
lstInventory = pickle.load(objFile)
print("Your inventory is as follows:")
for items in lstInventory:
    print(items)
