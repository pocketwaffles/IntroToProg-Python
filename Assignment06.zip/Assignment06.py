# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   RRoot
# Date:  July 16, 2012
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   Adam Wirtala, 08/08/2019, Added code to complete assignment 5
#   Adam Wirtala, 08/15/2019, Moved data processing into functions
# https://www.tutorialspoint.com/python/python_dictionary.htm
# -------------------------------------------------#

# -- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

# -- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)
# -------------------------------


# Declare Variables
objFileName = "C:\_PythonClass\Assignment06\ToDo.txt"
strData = ""
dictRow = {}
new_dict = {}
lstTable = []
tasks = []


class DataManipulation(object):

    # Step 1 - Load data from a file
    # When the program starts, load each "row" of data
    # in "ToDo.txt" into a python Dictionary.
    # Take data in CSV format and assign to dictionary.
    # Combines both items into 1 dictionary, removes carriage return.

    @staticmethod
    def loaddata():
        # Function to load data from previously defined file
        objFile = open(objFileName, "r")
        lines = objFile.readlines()
        objFile.close()
        for line in lines:
            ls = line.split(',')
            dictRow[ls[0]] = ls[1].strip()

        # Add the each dictionary "row" to a python list "table"
        # Working to unpack dictionary to create two separate dictionaries (rows) to format into list.

        for key, value in dictRow.items():
            lstTable.append({key: value})

    @staticmethod
    # Function to print out and display tasks and items from the task list.
    def showdata():
        for tasks in lstTable:
            for k, v in tasks.items():
                print(k, ":", v)

    @staticmethod
    # Function to add new items and priorities to the task list
    def addnew():
        while (True):
            dicNewRow = {}
            strTask = input("Please enter a Task: ")
            strPriority = input("Please list its Priority (high, medium, low): ")
            dicNewRow[strTask] = strPriority
            lstTable.append(dicNewRow)
            strAnotherItem = input("Would you like to add an additional item? (y/n): ")
            if strAnotherItem.lower() == 'n': break

    @staticmethod
    # Function to delete item from the task list
    def deleteitem():
        while (True):
            print("Enter '0' to return to menu")
            for i, item in enumerate(lstTable):
                print(i+1, item)
            x = int(input("Which item would you like to delete (enter the corresponding number)?: "))
            if x == 0: break
            del lstTable[x-1]
            print("Your current tasks are now: ")
            for i, item in enumerate(lstTable):
                print(i+1, item)
            strAnotherDelete = input("Would you like to delete another item? (y/n): ")
            if strAnotherDelete.lower() == 'n': break


    @staticmethod
    # Function to write data back to text file.
    def savedata():
        objFile = open(objFileName, "w")
        for tasks in lstTable:
            for k, v in tasks.items():
                objFile.write(k + "," + v + "\n")
        objFile.close()
        print("Data Saved to File!")

#----- Load Data from File ----- #
DataManipulation.loaddata()


#----- Input/Output ------#
# Step 2 - Display a menu of choices to the user
while (True):
    print("""

    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program

    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        DataManipulation.showdata()
        continue


    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        DataManipulation.addnew()
        continue

    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):
        DataManipulation.deleteitem()
        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        DataManipulation.savedata()
        continue

    # Step 7 - Exit the program
    elif (strChoice == '5'):
        break
